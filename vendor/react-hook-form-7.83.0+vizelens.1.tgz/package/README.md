# Offline source distribution for VizeLens

The JavaScript runtime is the upstream React Hook Form 7.83.0 ESM distribution,
retrieved through the available web reader from:
https://app.unpkg.com/react-hook-form@7.83.0/files/dist/index.esm.mjs

The source map comment was removed. The original MIT license is included.
The TypeScript declarations are a locally maintained, deliberately narrow surface
covering useForm, useFieldArray and useWatch used by VizeLens. They are not the
upstream declarations. No runtime reimplementation is included.

This archive exists because npm network access was unavailable during the build.
When network access is available, replace with the normal upstream dependency:
npm install react-hook-form@7.83.0
